#!/usr/bin/env python3

class DoubleLinkedNode:

    def __init__(self, val):
        self.value = val;
        self.next = None
        self.prev = None
